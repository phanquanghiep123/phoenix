function Categories() {
	this.table  = "categories";
	this.key    = "id";
}
module.exports = Categories;