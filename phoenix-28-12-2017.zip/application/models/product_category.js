function Product_Category() {
	this.table  = "product_category";
	this.key    = ["product_id","category_id"];
}
module.exports = Product_Category;