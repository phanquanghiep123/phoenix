function Users() {
	this.table  = "users";
	this.key    = "id";
}
module.exports = Users;