function Metas() {
	this.table  = "metas";
	this.key    = ["key_string","general_id"];
}
module.exports = Metas;