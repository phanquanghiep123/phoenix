function Products() {
	this.table  = "products";
	this.key    = "id";
}
module.exports = Products;