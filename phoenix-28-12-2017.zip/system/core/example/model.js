function {{NAME}}() {
	this.table  = "{TABLE}";
	this.key    = {{KEY}};
	this.colums = {{COLUMS}}
	{{ADD}}
}
module.exports = {{NAME}};