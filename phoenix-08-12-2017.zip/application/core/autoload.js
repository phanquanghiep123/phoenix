autoloadMyController([
	//{name : "MyController",file: "MyController"}
]);
/*autoloadMyModel([
	{name : "MyModel",file: "MyModel"}
]);*/