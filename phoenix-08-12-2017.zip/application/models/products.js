_Model.products ={
	getall : function(){
		write("<h2>Hello model products!</h2>");
	}
}