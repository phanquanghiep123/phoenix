var server_port = 80;
var server_ip_address = "phoenix.com";
_Config.local = {
	host : server_ip_address,
	port : server_port,
	defaulController : "home",
	defaulAction     : "index"
}