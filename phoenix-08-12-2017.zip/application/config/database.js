/*Config for drive mysql*/
_Config.database = {
	driver : "Mysql", //default null.
	Mysql  : {
		host: "localhost",
		user: "root",
		password: "",
		database: "dezignwall"
	},
	NoSQL : {
		host     : "127.0.0.1",
		user     : "root",
		password : "",
		database : "dezignwall",
	},
	PostgreSQL : {
		host     : "127.0.0.1",
		user     : "root",
		password : "",
		database : "dezignwall",
	},
	MongoDB : {
		host     : "127.0.0.1",
		user     : "root",
		password : "",
		database : "dezignwall",
	}
}