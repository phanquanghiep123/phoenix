function Config (){
	this.local;
	this.database;
}
module.exports = Config;